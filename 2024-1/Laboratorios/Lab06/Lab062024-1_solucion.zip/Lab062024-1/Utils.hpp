/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/* 
 * File:   Utils.hpp
 * Author: Erasmo G. Montoya
 *
 * Created on May 23, 2024, 10:18 PM
 */

#ifndef UTILS_HPP
#define UTILS_HPP

#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>

#endif /* UTILS_HPP */

