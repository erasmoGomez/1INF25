//
// Created by Erasmo on 24/06/25.
//

#ifndef STL_UTILS_HPP
#define STL_UTILS_HPP
#include <iostream>
#include <fstream>
#include <cstring>
#include <list>
#include <vector>
#include <map>
#include <iterator>
#include <algorithm>
using namespace std;
#endif //STL_UTILS_HPP
